import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import pool from './config/db.js';

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Rota de Health Check
app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// --- ROTAS DO SISTEMA ---

// Listar Indústrias
app.get('/api/industries', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM industries WHERE active = 1 ORDER BY order_index ASC');
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Obter Perguntas por Indústria
app.get('/api/questions/:industryId', async (req, res) => {
    const { industryId } = req.params;
    try {
        // Busca as seções
        const [sections] = await pool.query('SELECT * FROM sections WHERE industry_id = ? ORDER BY order_index ASC', [industryId]);

        // Para cada seção, busca suas perguntas
        const result = await Promise.all(sections.map(async (section) => {
            const [questions] = await pool.query('SELECT * FROM questions WHERE section_id = ? AND disabled = 0 ORDER BY order_index ASC', [section.id]);

            // Para cada pergunta, busca suas opções
            const questionsWithChoices = await Promise.all(questions.map(async (q) => {
                const [options] = await pool.query('SELECT * FROM question_options WHERE question_id = ? ORDER BY order_index ASC', [q.id]);
                return { ...q, options: options.map(o => o.text) }; // Mantendo formato do frontend
            }));

            // Busca feedback
            const [feedback] = await pool.query('SELECT * FROM section_feedbacks WHERE section_id = ?', [section.id]);

            return {
                ...section,
                questions: questionsWithChoices,
                feedback: feedback[0] ? {
                    levels: {
                        initial: feedback[0].initial_text,
                        basic: feedback[0].basic_text,
                        intermediate: feedback[0].intermediate_text,
                        advanced: feedback[0].advanced_text
                    }
                } : null
            };
        }));

        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Salvar Novo Diagnóstico
app.post('/api/diagnoses', async (req, res) => {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();

        const { id, industry_id, userInfo, total_score, maturity_level, answers, sectionScores } = req.body;

        // 1. Inserir Diagnóstico
        await connection.execute(`
            INSERT INTO diagnoses (
                id, industry_id, user_name, user_email, user_company, user_position, 
                etn, vendedor, tempo_orcamento, pessoas_processo, faturamento, 
                faixa_colaboradores, erp, total_score, maturity_level
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                id, industry_id, userInfo.nome, userInfo.email, userInfo.empresa, userInfo.cargo,
                userInfo.etn || null, userInfo.vendedor || null, userInfo.tempoOrcamento || null,
                userInfo.pessoasProcesso || null, userInfo.faturamento || null,
                userInfo.faixaColaboradores || null, userInfo.erp || null,
                total_score, maturity_level
            ]
        );

        // 2. Inserir Respostas
        for (const [qId, optIdx] of Object.entries(answers)) {
            await connection.execute(
                'INSERT INTO diagnosis_answers (diagnosis_id, question_id, selected_option_index, score_at_time) VALUES (?, ?, ?, ?)',
                [id, qId, optIdx, 0] // score_at_time pode ser calculado aqui se necessário
            );
        }

        // 3. Inserir Resultados por Seção
        for (const s of sectionScores) {
            await connection.execute(
                'INSERT INTO diagnosis_section_results (diagnosis_id, section_id, section_title, score, feedback_text) VALUES (?, ?, ?, ?, ?)',
                [id, s.id, s.title, s.score, s.feedback_calculated || null]
            );
        }

        await connection.commit();
        res.status(201).json({ message: 'Diagnóstico salvo com sucesso', id });
    } catch (error) {
        await connection.rollback();
        res.status(500).json({ error: error.message });
    } finally {
        connection.release();
    }
});

// Listar Histórico
app.get('/api/history', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM diagnoses ORDER BY created_at DESC');
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.listen(port, () => {
    console.log(`Backend DCVB rodando em http://localhost:${port}`);
});
